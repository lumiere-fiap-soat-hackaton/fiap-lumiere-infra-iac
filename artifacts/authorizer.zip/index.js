"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const shared_1 = require("@lumiere/shared");
const logger = (0, shared_1.createAppLogger)('AuthorizerFunction');
const clientId = process.env.AUTH_CLIENT_ID;
const clientSecret = process.env.AUTH_CLIENT_SECRET;
const handler = async (event) => {
    logger.debug('Received authorization request', { eventType: 'RequestAuthorizationAttempt', details: { event } });
    try {
        const accessToken = handleValidation(event.headers?.Cookie ?? event.headers?.cookie ?? '');
        const authService = new shared_1.AuthService(clientId, clientSecret);
        const result = await authService.fetchUserAttributes(accessToken);
        return {
            principalId: result.sub,
            policyDocument: {
                Version: '2012-10-17',
                Statement: [
                    {
                        Action: 'execute-api:Invoke',
                        Effect: 'Allow',
                        Resource: '*',
                    },
                ],
            },
            context: {
                userId: result.sub,
                scope: 'user',
            },
        };
    }
    catch (error) {
        const exception = (error instanceof shared_1.BaseException) ? error : new shared_1.UnexpectedErrorException(String(error));
        const { message, name, reason, stack } = exception;
        logger.error(message, { eventType: name, reason, stack });
        return {
            principalId: 'user',
            policyDocument: {
                Version: '2012-10-17',
                Statement: [
                    {
                        Action: 'execute-api:Invoke',
                        Effect: 'Deny',
                        Resource: '*',
                    },
                ],
            },
        };
    }
};
exports.handler = handler;
const handleValidation = (headerCookie) => {
    const accessToken = (0, shared_1.getCookie)(headerCookie, 'accessToken');
    if (!accessToken)
        throw new shared_1.NotAuthorizedException();
    return accessToken;
};
