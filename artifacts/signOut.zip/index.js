"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const shared_1 = require("@lumiere/shared");
const logger = (0, shared_1.createAppLogger)('SignOutFunction');
const clientId = process.env.AUTH_CLIENT_ID;
const clientSecret = process.env.AUTH_CLIENT_SECRET;
const handler = async (event) => {
    logger.debug('Received sign-out request', { eventType: 'SignOutAttempt', details: { event } });
    try {
        const accessToken = handleValidation(event.headers?.Cookie ?? event.headers?.cookie ?? '');
        const authService = new shared_1.AuthService(clientId, clientSecret);
        if (accessToken)
            await authService.signOutUser(accessToken);
        return {
            statusCode: 200,
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Set-Cookie': 'accessToken=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0',
            },
            /*multiValueHeaders: {
              'Cache-Control': 'no-cache, no-store, must-revalidate',
              'Set-Cookie': [
                `refreshToken=; Secure; HttpOnly; SameSite=Lax; Max-Age=0; Path=/`,
                `idToken=; Secure; HttpOnly; SameSite=Lax; Max-Age=0; Path=/`,
                `accessToken=; Secure; HttpOnly; SameSite=Lax; Max-Age=0; Path=/`,
              ],
            },*/
            body: JSON.stringify({ message: 'User signed out successfully' }),
        };
    }
    catch (error) {
        const exception = (error instanceof shared_1.BaseException) ? error : new shared_1.UnexpectedErrorException(String(error));
        const { message, name, reason, statusCode, stack } = exception;
        logger.error(message, { eventType: name, reason, stack });
        return {
            statusCode: statusCode,
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Set-Cookie': 'accessToken=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0',
            },
            /*multiValueHeaders: {
              'Cache-Control': 'no-cache, no-store, must-revalidate',
              'Set-Cookie': [
                `refreshToken=; Secure; HttpOnly; SameSite=Lax; Max-Age=0; Path=/`,
                `idToken=; Secure; HttpOnly; SameSite=Lax; Max-Age=0; Path=/`,
                `accessToken=; Secure; HttpOnly; SameSite=Lax; Max-Age=0; Path=/`,
              ],
            },*/
            body: JSON.stringify({ message, errorCode: name }),
        };
    }
};
exports.handler = handler;
const handleValidation = (headerCookie) => {
    const accessToken = (0, shared_1.getCookie)(headerCookie, 'accessToken');
    if (!accessToken) {
        logger.warn('No access token found in cookies, skipping authService signOutUser call');
    }
    return accessToken;
};
