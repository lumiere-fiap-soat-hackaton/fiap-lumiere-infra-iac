"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const shared_1 = require("@lumiere/shared");
const logger = (0, shared_1.createAppLogger)('SignInFunction');
const clientId = process.env.AUTH_CLIENT_ID;
const clientSecret = process.env.AUTH_CLIENT_SECRET;
const handler = async (event) => {
    logger.debug('Received sign-in request', { eventType: 'SignInAttempt', details: { event } });
    try {
        const body = JSON.parse(event.body || '{}');
        const authService = new shared_1.AuthService(clientId, clientSecret);
        handleValidation(body);
        const result = await authService.signInUser(body.username, body.password);
        return {
            statusCode: 200,
            headers: {
                'Set-Cookie': `accessToken=${result.AccessToken}; Secure; HttpOnly; SameSite=Lax; Path=/`,
            },
            /*multiValueHeaders: {
              'Set-Cookie': [
                `refreshToken=${result.RefreshToken}; Secure; HttpOnly; SameSite=Lax; Max-Age=${result.ExpiresIn * 2}; Path=/`,
                `idToken=${result.IdToken}; Secure; HttpOnly; SameSite=Lax; Max-Age=${result.ExpiresIn}; Path=/`,
                `accessToken=${result.AccessToken}; Secure; HttpOnly; SameSite=Lax; Max-Age=${result.ExpiresIn}; Path=/`,
              ],
            },*/
            body: JSON.stringify({ message: 'User signed in successfully' }),
        };
    }
    catch (error) {
        const exception = (error instanceof shared_1.BaseException) ? error : new shared_1.UnexpectedErrorException(String(error));
        const { message, name, reason, statusCode, stack } = exception;
        logger.error(message, { eventType: name, reason, stack });
        return {
            statusCode: statusCode,
            body: JSON.stringify({ message, errorCode: name }),
        };
    }
};
exports.handler = handler;
const handleValidation = (payload) => {
    const { username, password } = payload;
    if (!username || !password) {
        throw new shared_1.InvalidInputException(`Username and password are required for sign-up creation. 
         username received: ${!!username}, password received : ${!!password}`);
    }
};
