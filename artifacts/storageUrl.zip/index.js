"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const shared_1 = require("@lumiere/shared");
var StorageAction;
(function (StorageAction) {
    StorageAction["UPLOAD_URL"] = "upload-url";
    StorageAction["DOWNLOAD_URL"] = "download-url";
})(StorageAction || (StorageAction = {}));
const logger = (0, shared_1.createAppLogger)('StorageUrlFunction');
const bucketName = process.env.BUCKET_NAME;
const handler = async (event) => {
    logger.info('Received storage-url request', { eventType: 'StorageUrlRequestAttempt', details: { event } });
    try {
        const BUCKET_PATHS = {
            [StorageAction.UPLOAD_URL]: 'sources',
            [StorageAction.DOWNLOAD_URL]: 'results',
        };
        const userId = event.requestContext.authorizer?.userId;
        const items = JSON.parse(event.body ?? '[]');
        const action = event.pathParameters?.action ?? null;
        handleValidation(userId, items, action);
        const enhancedItems = items.map((item) => ({
            ...item,
            key: `${BUCKET_PATHS[action]}/${userId}/${item.fileName}`,
        }));
        const storageService = new shared_1.StorageService(bucketName);
        const strategies = {
            [StorageAction.UPLOAD_URL]: () => storageService.getBatchUploadUrls(enhancedItems),
            [StorageAction.DOWNLOAD_URL]: () => storageService.getBatchDownloadUrls(enhancedItems),
        };
        const result = await strategies[action]();
        return {
            statusCode: 200,
            body: JSON.stringify(result),
        };
    }
    catch (error) {
        const exception = (error instanceof shared_1.BaseException) ? error : new shared_1.UnexpectedErrorException(String(error));
        const { message, name, reason, statusCode, stack } = exception;
        logger.error(message, { eventType: name, reason, stack });
        return {
            statusCode: statusCode,
            body: JSON.stringify({ message, errorCode: name }),
        };
    }
};
exports.handler = handler;
const handleValidation = (userId, items, action) => {
    if (!action) {
        throw new shared_1.InvalidInputException(`URL pathParam for StorageUrl is missing or invalid. (expected: api/storage/{upload-url|download-url}`);
    }
    if (!userId) {
        throw new shared_1.NotAuthorizedException('User is not authorized to access this resource. Missing or invalid userId.');
    }
    if (!items.length) {
        throw new shared_1.InvalidInputException('Request body is missing or invalid. Expected a list of file items.');
    }
};
